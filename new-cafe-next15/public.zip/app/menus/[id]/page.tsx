import React from 'react';

const MenuPage: React.FC = () => {
    return (
      <main>
        상세페이지
      </main>
    );
};

export default MenuPage;