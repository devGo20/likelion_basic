export default function RootFooter() {
    return (
        <footer>
            footer
        </footer>
    );
}