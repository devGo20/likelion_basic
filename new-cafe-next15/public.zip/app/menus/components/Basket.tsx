import React from 'react';

const Basket: React.FC = () => {
    return (
        <div>
            <h2>장바구니</h2>
            <p>장바구니가 비어 있습니다.</p>
        </div>
    );
};

export default Basket;