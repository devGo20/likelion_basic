export default function Page() {
    return (
        <div>
          홈페이지에 오신것을 환영합니다.
        </div>
    );
}