const RootHeader = () => {
    return (
        <header>
            header
        </header>
    );
};

export default RootHeader;